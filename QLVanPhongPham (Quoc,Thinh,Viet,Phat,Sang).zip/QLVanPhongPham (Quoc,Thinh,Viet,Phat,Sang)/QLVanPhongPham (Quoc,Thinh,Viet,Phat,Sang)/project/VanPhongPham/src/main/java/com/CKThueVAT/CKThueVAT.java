package com.CKThueVAT;

public interface CKThueVAT{
    final double dVAT = 0.08;
    final double dCKSach = 0.03;
    final double dCKVo = 0.02;
    final double dCKBut = 0.015;
    final int iSoLuong = 10;
}